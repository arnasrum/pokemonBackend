package com.arnas.pokemans

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class PokemansApplicationTests {

	@Test
	fun contextLoads() {
	}

}
